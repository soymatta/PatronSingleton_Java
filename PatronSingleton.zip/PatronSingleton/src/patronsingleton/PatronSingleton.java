package patronsingleton;

public class PatronSingleton {
    
    public static void main(String[] args) {
    
        Singleton instancia1 = Singleton.getInstance(); // Variable de una instancia
        Singleton instancia2 = Singleton.getInstance(); // Variable de otra instancia

        System.out.println(instancia1 == instancia2); // Muestra si las variables hacen referencia a la misma instancia de Singleton
    
        
    }
    
}
